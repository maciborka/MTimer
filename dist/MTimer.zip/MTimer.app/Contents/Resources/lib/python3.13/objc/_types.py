"""
Helper for typing framework bindings
"""

NSInteger = int
NSUInteger = int
CGFloat = float
